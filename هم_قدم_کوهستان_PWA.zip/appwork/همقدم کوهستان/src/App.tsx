import { useEffect, useMemo, useState } from 'react';
import OpenAI from 'openai';
import {
  Bot,
  BookOpen,
  CheckCircle2,
  ChevronLeft,
  Clock3,
  Home,
  Lightbulb,
  MessageCircle,
  Pause,
  Play,
  Send,
  Sparkles,
  Target,
  UserRound,
  X,
} from 'lucide-react';

type FocusSession = { active: boolean; remaining: number; duration: number };
type Activity = { id: number; title: string; description: string; minutes: number; icon: typeof BookOpen; color: string };
type ChatMessage = { role: 'user' | 'assistant'; text: string };

const activities: Activity[] = [
  { id: 1, title: 'یک فصل بخوان', description: 'کتاب درسی یا غیردرسی، بدون باز کردن شبکه‌های اجتماعی.', minutes: 25, icon: BookOpen, color: 'bg-indigo-100 text-indigo-800' },
  { id: 2, title: 'مرورِ آرام درس', description: 'فقط یک مبحث کوچک را با دفتر و مداد مرور کن.', minutes: 20, icon: Target, color: 'bg-amber-100 text-amber-800' },
  { id: 3, title: 'استراحت بی‌صفحه', description: 'آب بخور، کشش انجام بده یا چند دقیقه با خانواده حرف بزن.', minutes: 10, icon: Home, color: 'bg-emerald-100 text-emerald-800' },
];

const pad = (value: number) => String(value).padStart(2, '0');

export default function App() {
  const [tab, setTab] = useState<'home' | 'activities' | 'coach'>('home');
  const [studentName, setStudentName] = useState(() => localStorage.getItem('focus-student-name') ?? '');
  const [draftName, setDraftName] = useState(() => localStorage.getItem('focus-student-name') ?? '');
  const [editingName, setEditingName] = useState(() => !localStorage.getItem('focus-student-name'));
  const [session, setSession] = useState<FocusSession>(() => {
    const saved = localStorage.getItem('focus-student-session');
    return saved ? JSON.parse(saved) as FocusSession : { active: false, remaining: 25 * 60, duration: 25 * 60 };
  });
  const [focusMinutes, setFocusMinutes] = useState(() => Number(localStorage.getItem('focus-student-minutes') ?? 0));
  const [doneActivities, setDoneActivities] = useState<number[]>(() => JSON.parse(localStorage.getItem('focus-student-activities') ?? '[]') as number[]);
  const [notice, setNotice] = useState('');
  const [question, setQuestion] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([{ role: 'assistant', text: 'سلام! من کنارتم تا شروع درس خواندن و کنار گذاشتن گوشی ساده‌تر شود. امروز دوست داری روی چه درسی تمرکز کنی؟' }]);
  const [asking, setAsking] = useState(false);
  const [coachError, setCoachError] = useState('');

  useEffect(() => localStorage.setItem('focus-student-session', JSON.stringify(session)), [session]);
  useEffect(() => localStorage.setItem('focus-student-minutes', String(focusMinutes)), [focusMinutes]);
  useEffect(() => localStorage.setItem('focus-student-activities', JSON.stringify(doneActivities)), [doneActivities]);

  useEffect(() => {
    if (!session.active) return;
    const timer = window.setInterval(() => {
      setSession((current) => {
        if (current.remaining <= 1) {
          window.clearInterval(timer);
          setFocusMinutes((minutes) => minutes + Math.round(current.duration / 60));
          setNotice('آفرین! یک بازهٔ تمرکز را کامل کردی.');
          return { ...current, active: false, remaining: current.duration };
        }
        return { ...current, remaining: current.remaining - 1 };
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [session.active]);

  const timeLeft = `${pad(Math.floor(session.remaining / 60))}:${pad(session.remaining % 60)}`;
  const percent = Math.round(((session.duration - session.remaining) / session.duration) * 100);
  const weeklyGoal = 180;
  const weeklyPercent = Math.min(100, Math.round((focusMinutes / weeklyGoal) * 100));
  const displayName = studentName || 'دوست من';
  const completedActivities = useMemo(() => activities.filter((activity) => doneActivities.includes(activity.id)), [doneActivities]);

  function saveName() {
    const name = draftName.trim();
    if (!name) { setNotice('لطفاً نامت را وارد کن تا برنامه برای خودت شود.'); return; }
    localStorage.setItem('focus-student-name', name);
    setStudentName(name);
    setEditingName(false);
    setNotice(`خوش اومدی ${name}! آماده‌ای یک قدم کوچک برداری؟`);
  }

  function toggleSession() { setNotice(''); setSession((current) => ({ ...current, active: !current.active })); }
  function resetSession() { setSession({ active: false, remaining: 25 * 60, duration: 25 * 60 }); setNotice('زمان‌سنج ۲۵ دقیقه‌ای آماده است. گوشی را دورتر بگذار.'); }

  function completeActivity(activity: Activity) {
    if (doneActivities.includes(activity.id)) return;
    setDoneActivities((current) => [...current, activity.id]);
    setFocusMinutes((minutes) => minutes + activity.minutes);
    setNotice(`«${activity.title}» به پیشرفت امروزت اضافه شد.`);
  }

  async function askCoach(event: React.FormEvent) {
    event.preventDefault();
    const text = question.trim();
    if (!text || asking) return;
    setQuestion('');
    setCoachError('');
    const nextMessages = [...messages, { role: 'user' as const, text }];
    setMessages(nextMessages);
    const serviceUrl = import.meta.env.VITE_PLATFORM_SERVICES_URL;
    const serviceToken = import.meta.env.VITE_PLATFORM_SERVICE_TOKEN;
    if (!serviceUrl || !serviceToken) {
      setCoachError('راهنمای هوشمند فعلاً در دسترس نیست. کمی بعد دوباره امتحان کن.');
      return;
    }
    setAsking(true);
    try {
      const client = new OpenAI({ baseURL: serviceUrl + '/openai/v1', apiKey: serviceToken, dangerouslyAllowBrowser: true });
      const response = await client.chat.completions.create({
        model: 'gpt-5.4-mini',
        max_completion_tokens: 700,
        messages: [
          { role: 'system', content: `تو راهنمای مهربان تمرکز برای دانش‌آموز ایرانی به نام ${displayName} هستی. پاسخ‌ها را فارسی، کوتاه، عملی و دلگرم‌کننده بده. فقط در زمینه تمرکز، عادت مطالعه، برنامه‌ریزی سبک و دوری سالم از گوشی کمک کن. ادعای قطعی پزشکی نکن.` },
          ...nextMessages.map((message) => ({ role: message.role, content: message.text })),
        ],
      });
      const answer = response.choices[0]?.message.content?.trim();
      if (!answer) throw new Error('empty response');
      setMessages((current) => [...current, { role: 'assistant', text: answer }]);
    } catch (error) {
      console.error('coach request failed', error);
      setCoachError('پاسخ گرفتن ممکن نشد. لطفاً کمی بعد دوباره تلاش کن.');
    } finally { setAsking(false); }
  }

  const navItems = [
    { id: 'home' as const, label: 'امروز', icon: Home },
    { id: 'activities' as const, label: 'برنامه‌ها', icon: CheckCircle2 },
    { id: 'coach' as const, label: 'راهنمای هوشمند', icon: Bot },
  ];

  return (
    <main className="min-h-screen bg-[#f7f5ef] text-slate-800" data-testid="app-shell">
      <div className="mx-auto min-h-screen w-full max-w-6xl px-4 pb-28 pt-5 sm:px-6 lg:px-8 lg:pb-10">
        <header className="mb-6 flex items-center justify-between gap-3" data-testid="header">
          <div className="flex min-w-0 items-center gap-3"><div className="grid size-12 shrink-0 place-items-center rounded-2xl bg-indigo-800 text-white shadow-lg shadow-indigo-950/20"><Sparkles size={24} /></div><div className="min-w-0"><p className="text-lg font-black">خانهٔ تمرکز</p><p className="truncate text-sm text-slate-500">ویژهٔ دانش‌آموزها، دور از حواس‌پرتی</p></div></div>
          <button data-testid="edit-name-button" onClick={() => setEditingName(true)} className="flex min-h-11 items-center gap-2 rounded-2xl border border-stone-200 bg-white px-3 text-sm font-bold text-slate-700 transition hover:border-indigo-300" aria-label="ویرایش نام"><UserRound size={18} /><span className="hidden sm:inline">{studentName || 'نام من'}</span></button>
        </header>

        {editingName && <section className="mb-5 rounded-[1.5rem] border border-indigo-200 bg-indigo-50 p-4 sm:flex sm:items-end sm:gap-4" data-testid="name-form"><div className="min-w-0 flex-1"><label htmlFor="student-name" className="mb-2 block text-sm font-bold text-indigo-950">اسمت چیه؟</label><input id="student-name" data-testid="student-name-input" value={draftName} onChange={(event) => setDraftName(event.target.value)} onKeyDown={(event) => event.key === 'Enter' && saveName()} placeholder="مثلاً آوا" maxLength={30} className="min-h-12 w-full rounded-xl border border-indigo-200 bg-white px-4 text-base outline-none transition focus:border-indigo-700 focus:ring-4 focus:ring-indigo-100" /></div><button data-testid="save-name-button" onClick={saveName} className="mt-3 min-h-12 w-full rounded-xl bg-indigo-800 px-5 font-bold text-white transition hover:bg-indigo-950 sm:mt-0 sm:w-auto">شروع کنیم</button></section>}
        {notice && <div className="mb-5 flex items-start justify-between gap-3 rounded-2xl border border-indigo-200 bg-indigo-50 px-4 py-3 text-sm font-medium text-indigo-950" role="status" data-testid="status-notice"><span>{notice}</span><button data-testid="close-notice" onClick={() => setNotice('')} className="rounded-lg p-1 hover:bg-indigo-100" aria-label="بستن پیام"><X size={17} /></button></div>}

        {tab === 'home' && <section data-testid="home-screen"><div className="mb-6 overflow-hidden rounded-[2rem] bg-gradient-to-br from-indigo-950 via-indigo-900 to-violet-800 p-6 text-white shadow-xl shadow-indigo-950/20 sm:p-8"><span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-sm font-bold text-indigo-50"><Lightbulb size={16} /> یک قدم کوچک کافی است</span><h1 className="mt-4 text-3xl font-black leading-tight sm:text-4xl">سلام {displayName}،<br />امروز برای خودت وقت می‌سازی.</h1><p className="mt-3 max-w-xl text-base leading-8 text-indigo-100">گوشی را کمی دورتر بگذار؛ یک بازهٔ کوتاه درس یا استراحت آرام، شروعی واقعی برای تمرکز است.</p></div>
          <div className="grid gap-5 lg:grid-cols-[1.1fr_.9fr]"><section className="rounded-[2rem] border border-stone-200 bg-white p-5 shadow-sm sm:p-7" data-testid="focus-card"><div className="flex items-start justify-between gap-4"><div><p className="text-sm font-bold text-indigo-800">زمانِ بدون گوشی</p><h2 className="mt-1 text-2xl font-black">تمرکز همین حالا</h2></div><Clock3 className="text-indigo-800" size={26} /></div><div className="my-7 grid place-items-center"><div className="relative grid size-48 place-items-center rounded-full" style={{ background: `conic-gradient(#4338ca ${percent}%, #e7e5e4 0)` }}><div className="grid size-[10.7rem] place-items-center rounded-full bg-white text-center"><span className="text-4xl font-black tabular-nums" data-testid="focus-time">{timeLeft}</span><span className="mt-1 text-sm text-slate-500">زمان تمرکز</span></div></div></div><div className="flex gap-3"><button data-testid="focus-toggle" onClick={toggleSession} className="flex min-h-12 flex-1 items-center justify-center gap-2 rounded-2xl bg-indigo-800 px-4 py-3 font-bold text-white transition hover:bg-indigo-950"><>{session.active ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" />}</>{session.active ? 'مکث کن' : 'شروع تمرکز'}</button><button data-testid="focus-reset" onClick={resetSession} className="min-h-12 rounded-2xl border border-stone-200 px-4 font-bold text-slate-600 transition hover:bg-stone-50">دوباره</button></div></section>
          <aside className="rounded-[2rem] border border-stone-200 bg-[#fffdf8] p-5 shadow-sm sm:p-7"><p className="text-sm font-bold text-indigo-800">پیشرفت هفتهٔ تو</p><div className="mt-3 flex items-end gap-2"><span className="text-5xl font-black" data-testid="focus-minutes">{focusMinutes}</span><span className="mb-1 text-slate-500">دقیقه از {weeklyGoal}</span></div><div className="mt-6 h-3 overflow-hidden rounded-full bg-stone-200"><div data-testid="weekly-progress" className="h-full rounded-full bg-indigo-700 transition-all" style={{ width: `${weeklyPercent}%` }} /></div><p className="mt-3 text-sm leading-6 text-slate-500">{weeklyPercent >= 100 ? 'هدف هفته را کامل کردی؛ عالیه!' : `${weeklyGoal - focusMinutes} دقیقه تا هدف این هفته مانده.`}</p><button data-testid="open-coach-button" onClick={() => setTab('coach')} className="mt-5 flex min-h-12 w-full items-center justify-center gap-2 rounded-2xl border border-indigo-800 px-4 font-bold text-indigo-900 transition hover:bg-indigo-50"><Bot size={19} /> از راهنمای هوشمند بپرس</button></aside></div></section>}

        {tab === 'activities' && <section data-testid="activities-screen"><div className="mb-6"><p className="text-sm font-bold text-indigo-800">قدم‌های ساده برای امروز</p><h1 className="mt-1 text-3xl font-black sm:text-4xl">برنامهٔ {displayName}</h1><p className="mt-2 text-base leading-7 text-slate-500">هر مورد را بعد از انجام دادن ثبت کن تا زمانت به پیشرفت هفتگی اضافه شود.</p></div><div className="grid gap-4 md:grid-cols-3">{activities.map((activity) => { const Icon = activity.icon; const complete = doneActivities.includes(activity.id); return <article key={activity.id} className="rounded-[1.75rem] border border-stone-200 bg-white p-5 shadow-sm" data-testid={`activity-card-${activity.id}`}><div className={`grid size-12 place-items-center rounded-2xl ${activity.color}`}><Icon size={23} /></div><h2 className="mt-5 text-xl font-black">{activity.title}</h2><p className="mt-2 min-h-14 text-sm leading-6 text-slate-600">{activity.description}</p><p className="mt-4 font-bold text-indigo-800">حدود {activity.minutes} دقیقه</p><button data-testid={`complete-activity-${activity.id}`} disabled={complete} onClick={() => completeActivity(activity)} className={`mt-5 flex min-h-12 w-full items-center justify-center gap-2 rounded-2xl px-4 font-bold transition ${complete ? 'bg-emerald-50 text-emerald-800' : 'bg-indigo-800 text-white hover:bg-indigo-950'}`}><CheckCircle2 size={19} />{complete ? 'ثبت شد' : 'انجام دادم'}</button></article>; })}</div>{completedActivities.length > 0 && <p className="mt-6 text-center text-sm font-bold text-emerald-800" data-testid="completed-activities">امروز {completedActivities.length} فعالیت را ثبت کرده‌ای.</p>}</section>}

        {tab === 'coach' && <section className="mx-auto max-w-3xl" data-testid="coach-screen"><div className="mb-6"><p className="text-sm font-bold text-indigo-800">همراهِ تمرکز تو</p><h1 className="mt-1 text-3xl font-black sm:text-4xl">راهنمای هوشمند</h1><p className="mt-2 text-base leading-7 text-slate-500">برای شروع درس، برنامهٔ کوتاه یا کنار گذاشتن گوشی از او کمک بگیر.</p></div><div className="rounded-[2rem] border border-stone-200 bg-white p-4 shadow-sm sm:p-6"><div className="max-h-[48dvh] min-h-72 space-y-4 overflow-y-auto pe-1" data-testid="coach-messages">{messages.map((message, index) => <div key={`${message.role}-${index}`} className={`flex gap-3 ${message.role === 'user' ? 'justify-start' : 'justify-end'}`}><div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-7 ${message.role === 'user' ? 'bg-indigo-800 text-white' : 'bg-stone-100 text-slate-700'}`} data-testid={`coach-message-${index}`}>{message.text}</div></div>)}{asking && <div className="flex justify-end"><div className="rounded-2xl bg-stone-100 px-4 py-3 text-sm text-slate-500">راهنما در حال فکر کردن است…</div></div>}</div>{coachError && <p className="mt-4 rounded-xl bg-rose-50 px-4 py-3 text-sm font-medium text-rose-800" data-testid="coach-error">{coachError}</p>}<form onSubmit={askCoach} className="mt-5 flex gap-2"><input data-testid="coach-input" value={question} onChange={(event) => setQuestion(event.target.value)} placeholder="مثلاً برای ریاضی چطور شروع کنم؟" className="min-h-12 min-w-0 flex-1 rounded-2xl border border-stone-200 px-4 text-sm outline-none transition focus:border-indigo-700 focus:ring-4 focus:ring-indigo-100" /><button data-testid="coach-send" disabled={!question.trim() || asking} className="grid size-12 shrink-0 place-items-center rounded-2xl bg-indigo-800 text-white transition hover:bg-indigo-950 disabled:bg-slate-300" aria-label="ارسال پرسش"><Send size={19} /></button></form></div><div className="mt-4 flex flex-wrap gap-2">{['یک برنامه ۲۰ دقیقه‌ای بده', 'حواسم پرت می‌شود، چه کنم؟', 'چطور گوشی را کنار بگذارم؟'].map((suggestion) => <button key={suggestion} data-testid={`coach-suggestion-${suggestion}`} onClick={() => setQuestion(suggestion)} className="rounded-full border border-stone-200 bg-white px-3 py-2 text-sm font-bold text-slate-600 transition hover:border-indigo-300 hover:text-indigo-800">{suggestion}</button>)}</div></section>}
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-10 border-t border-stone-200 bg-white/95 px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-2 backdrop-blur lg:static lg:mx-auto lg:max-w-6xl lg:border-0 lg:bg-transparent lg:px-8 lg:pb-8" aria-label="ناوبری اصلی" data-testid="bottom-navigation"><div className="mx-auto flex max-w-md items-center justify-around gap-2 lg:max-w-full lg:justify-start lg:gap-3">{navItems.map((item) => { const Icon = item.icon; const active = tab === item.id; return <button key={item.id} data-testid={`nav-${item.id}`} onClick={() => setTab(item.id)} className={`flex min-h-12 flex-1 flex-col items-center justify-center gap-1 rounded-2xl px-2 text-[11px] font-bold transition lg:max-w-44 lg:flex-row lg:px-3 lg:text-sm ${active ? 'bg-indigo-800 text-white shadow-md shadow-indigo-900/15' : 'text-slate-500 hover:bg-stone-100 hover:text-indigo-900'}`}><Icon size={18} strokeWidth={active ? 2.7 : 2} />{item.label}</button>; })}</div></nav>
    </main>
  );
}
